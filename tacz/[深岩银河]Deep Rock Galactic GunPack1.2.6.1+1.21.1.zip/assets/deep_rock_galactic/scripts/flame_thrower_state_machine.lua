local default = require("tacz_default_state_machine")

local GUN_KICK_TRACK_LINE = GUN_KICK_TRACK_LINE
local BOLT_CAUGHT_TRACK = default.BOLT_CAUGHT_TRACK
local bolt_caught_states = default.bolt_caught_states
local ammo_state = setmetatable({}, {__index = bolt_caught_states.normal})

local gun_kick_state = setmetatable({
}, {__index = default.gun_kick_state})

function gun_kick_state.transition(this, context, input)
    -- 玩家按下开火键时需要在射击轨道行里寻找空闲轨道去播放射击动画(如果没有空闲会分配新的),需要注意的是射击动画要向下混合
    if (input == INPUT_SHOOT) then
        local last_time = context:getLastShootTimestamp()
        local current_time = context:getCurrentTimestamp()
        local track = context:findIdleTrack(GUN_KICK_TRACK_LINE, false)
        local shootName = "shoot"
        if (current_time - last_time) >= 500 then
            shootName = "shoot_first"
        end---若发现本次开火距离上次开火时长间隔超过1500ms(1.5秒)，则将本次播放的动画名改为shoot_first
        -- 这里是混合动画，一般是可叠加的 gun kick
        context:runAnimation(shootName, track, true, PLAY_ONCE_STOP, 0)
    end
    local ammo = (context:getAmmoCount()/context:getMaxAmmoCount())
    context:setAnimationProgress(context:getTrack(STATIC_TRACK_LINE, BOLT_CAUGHT_TRACK),ammo,true)
    return nil
end

function ammo_state.entry(this, context)
    -- 因为进入不空挂状态没什么需要做的,因此什么都不做直接转进该状态
    context:runAnimation("ammo_display",context:getTrack(STATIC_TRACK_LINE, BOLT_CAUGHT_TRACK), false, PLAY_ONCE_HOLD, 0)
    context:pauseAnimation(context:getTrack(STATIC_TRACK_LINE, BOLT_CAUGHT_TRACK))
end

local M = setmetatable({
    gun_kick_state = gun_kick_state,
    bolt_caught_states = setmetatable({
        normal = ammo_state
    },{__index = bolt_caught_states}),
}, {__index = default})

function M:initialize(context)
    default.initialize(self, context)
end

return M